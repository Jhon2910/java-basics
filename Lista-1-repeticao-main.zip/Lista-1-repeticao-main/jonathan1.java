public class jonathan1 {
    public static void main(String[]args){

        for (int n = 1; n <= 100 ; n++){
            System.out.println("numero " + n);
        }
    }
}
