import java.util.Scanner;

public class jonathan2 {
    public static void main(String[]args){

        for (int n = 0 ;n <= 50; n = n + 2){
            System.out.println("numero "+ n);
        }

        }
    }
