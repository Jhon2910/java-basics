import java.util.Scanner;

public class jonathan3 {
    public static void main(String[]args){

        for (int n = 100;n >= 0;n=n-1){
            System.out.println("numero" +n);
        }
    }
}
